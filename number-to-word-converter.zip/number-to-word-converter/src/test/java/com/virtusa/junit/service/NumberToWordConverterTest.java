package com.virtusa.junit.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.virtusa.codetest.exception.InvalidNumberException;
import com.virtusa.codetest.service.NumberToWordConverter;

/**
 * @author Naganika
 *
 */
class NumberToWordConverterTest {
	NumberToWordConverter converterService;
	
	@BeforeEach
	void init() {
		converterService = new NumberToWordConverter();
	}

	/**
	 * Testcase to validate 0 as input
	 */
	@Test
	void testZero() {
		String expected = "zero";
		assertEquals(expected, converterService.convert("0"));
	}
	/**
	 * Testcase to validate any single digit number as input
	 */
	@Test
	void testOne_Nine() {
		String expected = "eight";
		assertEquals(expected, converterService.convert("8"));
	}
	/**
	 * Testcase to validate double digit number as input
	 */
	@Test
	void testTwoDigit() {
		String expected = "seventy seven";
		assertEquals(expected, converterService.convert("77"));
	}
	/**
	 * Testcase to validate 3 digit number as input
	 */
	@Test
	void testThreeDigit() {
		String expected = "four hundred and eighty six";
		assertEquals(expected, converterService.convert("486"));
	}
	/**
	 * Testcase to validate 100 as input
	 */
	@Test
	void testHundred() {
		String expected = "one hundred";
		assertEquals(expected, converterService.convert("100"));
	}
	/**
	 * Testcase to validate any number in thousands as input
	 */
	@Test
	void testThousands() {
		String expected = "four thousand nine hundred and seventy";
		assertEquals(expected, converterService.convert("4970"));
	}
	/**
	 * Testcase to validate any number in millions as input
	 */
	@Test
	void testMillions() {
		String expected = "three hundred and forty six million four hundred and fifty seven thousand four hundred and fifty six";
		assertEquals(expected, converterService.convert("346457456"));
	}
	/**
	 * Testcase to validate any number less than 0 as input
	 */
	@Test
	void testLessThanZero() {
		assertThrows(InvalidNumberException.class, () -> converterService.convert("-2"));
	}
	/**
	 * Testcase to validate any number greater than 999999999 as input
	 */
	@Test
	void testGreaterThanMax() {
		assertThrows(InvalidNumberException.class, () -> converterService.convert("1000000000"));
	}
	/**
	 * Testcase to validate any char as input
	 */
	@Test
	void testInvalidInput() {
		assertThrows(NumberFormatException.class, () -> converterService.convert("c"));		
	}

}
