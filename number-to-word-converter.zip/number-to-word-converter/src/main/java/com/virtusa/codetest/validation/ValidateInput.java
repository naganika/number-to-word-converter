package com.virtusa.codetest.validation;

/**
 * @author Naganika
 *
 */
public interface ValidateInput {
	/**
	 * @param number - input number to validate
	 * @return	true/false
	 */
	public boolean validate(int number);
}
