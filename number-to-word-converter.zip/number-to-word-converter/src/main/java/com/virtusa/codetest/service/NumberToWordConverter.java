package com.virtusa.codetest.service;

import com.virtusa.codetest.exception.InvalidNumberException;
import com.virtusa.codetest.validation.ValidateInput;

/**
 * @author Naganika
 *
 */
public class NumberToWordConverter {
	
	private static final String unitsArray[] = { "zero", "one", "two", "three", "four", "five", "six", 
            "seven", "eight", "nine", "ten", "eleven", "twelve",
            "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", 
            "eighteen", "nineteen" };
	private static final String tensArray[] = { "zero", "ten", "twenty", "thirty", "forty", "fifty",
            "sixty", "seventy", "eighty", "ninety" };
	
	
	/**
	 * @param inputStr - Input number passed from command line arguments 
	 * @return	String representation of number in words
	 */
	public String convert(String inputStr) {
	    String words = "";
	    
	    int number = Integer.parseInt(inputStr);

	    // validate input number
	    ValidateInput obj = (int input) -> (input > 999999999 || input < 0) ? false : true;
	    
	    if(obj.validate(number)) {	 
	    	// call numberToWord method to get String representation of number in words
	    	words = numberToWord(number);
			
	    	// Check and remove ' and' at the end. For eg, if we pass 100 as number, words will be 'one hundred and '
			if(words!=null ) {
				words = words.trim();
				if(words.length()>4 && " and".equals(words.substring(words.length()-4))) { 
					words = words.substring(0,words.length()-4); 
				}	
			}
	    } else {
	    	throw new InvalidNumberException("Please input any number between 0 and 999,999,999");
	    }
		return words;
	}
	
	/**
	 * @param number
	 * @return words
	 */
	private String numberToWord(int number) {

		String words = "";
		if (number == 0) {
			words = "zero";
		}
		// check if number is divisible by 1 million
		if ((number / 1000000) > 0) {
			words += numberToWord(number / 1000000) + " million ";
			number %= 1000000;
		}
		// check if number is divisible by 1 thousand
		if ((number / 1000) > 0) {
			words += numberToWord(number / 1000) + " thousand ";
			number %= 1000;
		}
		// check if number is divisible by 1 hundred
		if ((number / 100) > 0) {
			words += numberToWord(number / 100) + " hundred and ";
			number %= 100;
		}
		if (number > 0) {
			// check if number is within tens
			if (number < 20) {
				// fetch the appropriate value from unit array
				words += unitsArray[number];
			} else {
				// fetch the appropriate value from tens array
				words += tensArray[number / 10];
				if ((number % 10) > 0) {
					words += " " + unitsArray[number % 10];
				}
			}
		}
		return words;

	}
}
