package com.virtusa.codetest.exception;

/**
 * @author Naganika
 *
 */
public class InvalidNumberException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	
	/**
	 * @param s	- message to pass in case of exception
	 */
	public InvalidNumberException(String s) {
		super(s);
	}

}
