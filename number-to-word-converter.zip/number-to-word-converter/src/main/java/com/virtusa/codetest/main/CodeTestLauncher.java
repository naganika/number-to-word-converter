package com.virtusa.codetest.main;

import com.virtusa.codetest.exception.InvalidNumberException;
import com.virtusa.codetest.service.NumberToWordConverter;

/**
 * @author Naganika
 * This class takes the input number from command line arguments 
 * and then call NumberToWordConverter.convert() method to convert the number to its corresponding word
 * and prints the output to console.
 */
public class CodeTestLauncher {

	/**
	 * @param args - command line arguments
	 *  
	 */
	public static void main(String[] args) {
			
		   String output = "";	   
		   try {
			   NumberToWordConverter converterService = new NumberToWordConverter();
			   output = converterService.convert(args[0]);
			   if(output != null && output.length()>0)
				   System.out.print("Input Number in words: " + output);
		   } 
		   catch (NumberFormatException e) {
			   System.out.println("NumberFormatException caught in main method. Please pass valid number. " + e.getMessage());			   
		   }
		   catch (ArrayIndexOutOfBoundsException e) {
			   System.out.println("ArrayIndexOutOfBoundsException caught in main method. Please pass any valid number through command line arguments.");			   
		   }
		   catch (InvalidNumberException e) {
			   System.out.println("InvalidNumberException caught in main method: "+ e.getMessage());			   
		   }
		   catch (Exception e) {
			   System.out.println("Unknown Exception caught in main method: " + e.getMessage());
		   }
			
	   }
 
}
